/*
 * Alipay.com Inc.
 * Copyright (c) 2004-${YEAR} All Rights Reserved.
 */
